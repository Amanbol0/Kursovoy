<?php
require('../../controllers/Menu.php');
$db = new Menu();
$id = $_POST['id'];
$name = $_POST['name'];
$description = $_POST['description'];
$price = $_POST['price'];

$response = $db->createMenu(json_encode([
    'id'=>$id,
    'name'=>$name,
    'description'=>$description,
    'price'=>$price,
]));

header('Location: ../index2.php?message='.json_decode($response)->message);