<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
?>
<div>
    <a class="knopka" href="menu.php">Назад</a>
</div>
<div class="container mt-5">
    <form action="../../middleware/admin/create_staff.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-3">
            <label for="date">Дата</label>
            <input id="date" name="date" type="date" class="form-control" required>
        </div>
        <div class="col-3">
            <label for="name_dish">Название блюда</label>
            <input id="name_dish" name="name_dish" type="text" class="form-control" placeholder="Название" required>
        </div>
        <div class="col-3">
            <label for="price">Цена</label>
            <input id="price" name="price" type="text" class="form-control" placeholder="Цена" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div>


