<div><a class="knopka" href="index.php">Главная страница</a></div>
<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
?>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <div class="labelor">Заказы</div>
    <div>
        <a class="knopka" href="../menuha2.php">Блюда</a>
        <a class="knopka" href="../officiants/create.php">Добавить заказ</a>
        <a class="knopka" href="../officiants/delete.php">Удалить заказ</a>
    </div>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th> </th>
        <th>Дата</th>
        <th>Название услуги</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $db= new Orders();
    $data = $db->get();
    foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo ++$key;?></td>
            <td><?php echo $row['date'];?></td>
            <td><?php echo $row['name_dish'];?></td>
            <td><?php echo $row['price'];?></td>
        </tr>
    <?php }?>
    </tbody>
</table>
