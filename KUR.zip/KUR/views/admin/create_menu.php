<?php
require_once ('../layout/header.php');
require_once ('../../controllers/Menu.php');
?>
<div>
    <a class="knopka" href="menu.php">Назад</a>
</div>
<div class="container mt-5">
    <form action="../../middleware/admin/create_menu.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-5">
            <label for="name">Название</label>
            <input id="name" name="name" type="text" class="form-control" placeholder="Введите название блюда" required>
        </div>
        <div class="col-5">
            <label for="description">Описание</label>
            <input id="description" name="description" type="text" class="form-control" placeholder="Введите описание" required>
        </div>
        <div class="col-5">
            <label for="price">Стоимость</label>
            <input id="price" name="price" type="text" class="form-control" placeholder="Стоимость" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Добавить</button>
        </div>
    </form>
</div>

