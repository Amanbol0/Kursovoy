<?php
require ('layout/header.php');
require ('../controllers/Menu.php');
?>
<div>
    <a class="knopka" href="admin/menu.php">В меню</a>
</div>
<title>Технический отдел по ремонту техники</title>
<div class="container mx-auto">
    <table class="table table-hover table-dark">
        <thead>
        <tr>
            <th> </th>
            <th>Название</th>
            <th>Сроки</th>
            <th>Стоимость</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $db= new Menu();
        $data = $db->getData();
        foreach ($data as $key=>$row){
            ?>
            <tr>
                <td><?php echo ++$key;?></td>
                <td><?php echo $row['name'];?></td>
                <td><?php echo $row['description'];?></td>
                <td><?php echo $row['price'];?></td>
            </tr>
        <?php }?>
        </tbody>
    </table>
</div>

