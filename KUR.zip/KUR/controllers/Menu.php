<?php

require ('db.php');

class Menu extends DB
{
    public function getdata(){
        return $this->DBAll('SELECT * from menu');
    }
    public function createMenu($request){
        $req = json_decode($request);
        $name = $req->name;
        $description = $req->description;
        $price = $req->price;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO menu (name,description,price) values ('{$name}','{$description}','{$price}')");
            $connect->commit();
            return json_encode([
                'message'=>'Услуга добавлена'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function deleteMenu($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE FROM menu WHERE id='.$req->id,
            'Услуга удалена');
    }
    public function updateMenu($request){
        $req = json_decode($request);
        $id = $req->id;
        $name = $req->name;
        $description = $req->description;
        $price = $req->price;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE menu SET name='{$name}', description='{$description}', price='{$price}' WHERE id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Услуга обновлена'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }

}