<?php

require ('db.php');

class Staff extends DB
{
    public function get(){
        return $this->DBAll('SELECT * from officiants');
    }

    public function deleteOfficiant($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from officiants where id='.$req->id,
            'Пользователь удален');
    }

    public function createOfficiant($request){
        $req = json_decode($request);
        $last_name = $req->last_name;
        $name = $req->name;
        $father_name = $req->father_name;
        $experience = $req->experience;
        $wages = $req->wages;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO officiants (last_name,name,father_name,experience,wages) values ('{$last_name}','{$name}','{$father_name}','{$experience}','{$wages}')");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateOfficiant($request){
        $req = json_decode($request);
        $id = $req->id;
        $last_name = $req->last_name;
        $name = $req->name;
        $father_name = $req->father_name;
        $experience = $req->experience;
        $wages = $req->wages;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE officiants SET last_name='{$last_name}', name='{$name}', father_name='{$father_name}', experience='{$experience}',wages='{$wages}'
                  WHERE id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }

}